#ifndef __PARA_H
#define __PARA_H


int limit_ab(int x, int a, int b);

float f_abs(float x);

void sudu_zero(void);

float square(float x) ;
#endif
