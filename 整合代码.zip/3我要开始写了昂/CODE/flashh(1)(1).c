#include "headfile.h"
#include "stdlib.h"
int your_var[43],yourr_var[43];
uint8 hhh[4],hh[4];
int ii,jj,kk,ll;
void flashfz(void)
{
	your_var[0]=motor.left.giveset_speed;
	your_var[1]=motor.right.giveset_speed;
	your_var[2]=100*PID_para.speedL.kP;
	your_var[3]=100*PID_para.speedL.kI;
	your_var[4]=100*PID_para.speedR.kP;
	your_var[5]=100*PID_para.speedR.kI;
	your_var[6]=100*PID_para.angular.kP;
	your_var[7]=100*PID_para.angular.kD;
	your_var[8]=PID_fenduan.turnto.turnP1;
	your_var[9]=PID_fenduan.turnto.turnD1;
	your_var[10]=PID_fenduan.turnto.turnP2;
	your_var[11]=PID_fenduan.turnto.turnD2;
	your_var[12]=element.round.dir;
	your_var[13]=element.round.length1;

	your_var[16]=element.round.alllength;
	your_var[17]=element.barrier.rampLength;
	your_var[18]=element.barrier.decisionRange1;
	your_var[19]=element.barrier.decisionRange2;
	your_var[20]=PID_fenduan.turnto.turnP3;
	your_var[21]=PID_fenduan.turnto.turnD3;
	your_var[22]=element.barrier.ramp;
	your_var[23]=element.barrier.length1;
	your_var[24]=element.barrier.length2;
	your_var[25]=element.barrier.length3;
	your_var[26]=imu.Yaw1;
	your_var[27]=element.round.left_yaw;
	your_var[28]=element.round.right_yaw;
	
	your_var[33]=motor.left.gogo_givespeed;
	your_var[34]=motor.right.gogo_givespeed;
	your_var[35]=motor.left.error;
	your_var[36]=motor.right.error;
	
	your_var[37]=element.round.length2;
	your_var[38]=element.round.length3;
	your_var[39]=element.round.symbol;//int
	your_var[40]=element.round.dir2;//int
}

void flashzt(void)
{
	if(yourr_var[1]!=-1.0)
	{
		motor.left.giveset_speed=yourr_var[0];
		motor.right.giveset_speed=yourr_var[1];
		PID_para.speedL.kP=(float)yourr_var[2];
		PID_para.speedL.kP/=100;
		PID_para.speedL.kI=(float)yourr_var[3];
		PID_para.speedL.kI/=100;
		PID_para.speedR.kP=(float)yourr_var[4];
		PID_para.speedR.kP/=100;
		PID_para.speedR.kI=(float)yourr_var[5];
		PID_para.speedR.kI/=100;
		PID_para.angular.kP=(float)yourr_var[6];
		PID_para.angular.kP/=100;
		PID_para.angular.kD=(float)yourr_var[7];
		PID_para.angular.kD/=100;
		PID_fenduan.turnto.turnP1=yourr_var[8];
		PID_fenduan.turnto.turnD1=yourr_var[9];
		PID_fenduan.turnto.turnP2=yourr_var[10];
		PID_fenduan.turnto.turnD2=yourr_var[11];
		element.round.dir=yourr_var[12];
		element.round.length1=yourr_var[13];

		element.round.alllength=yourr_var[16];
		element.barrier.rampLength=yourr_var[17];
		element.barrier.decisionRange1=yourr_var[18];
		element.barrier.decisionRange2=yourr_var[19];
		PID_fenduan.turnto.turnP3=yourr_var[20];
		PID_fenduan.turnto.turnD3=yourr_var[21];
		element.barrier.ramp=yourr_var[22];
		element.barrier.length1=yourr_var[23];
		element.barrier.length2=yourr_var[24];
		element.barrier.length3=yourr_var[25];
		imu.Yaw1=yourr_var[26];
		element.round.left_yaw=yourr_var[27];
		element.round.right_yaw=yourr_var[28];
		
		motor.left.gogo_givespeed=yourr_var[33];
		motor.right.gogo_givespeed=yourr_var[34];
		motor.left.error=yourr_var[35];
		motor.right.error=yourr_var[36];
		element.round.length2=yourr_var[37];
		element.round.length3=yourr_var[38];
		element.round.symbol=yourr_var[39];
		element.round.dir2=yourr_var[40];
	}
}

void flash_read(void)
{
    iap_init();
	iap_read_bytes(0,&yourr_var,256); //��0��ʼ�������ȡ���4*8=32λ����
}

void flash_write(void)
{
    iap_init();
    iap_erase_page(0);//���������һҳ,��0��ʼ��
	iap_write_bytes(0, &your_var, 256);//��0��ʼ�Ѷ���д������
}
