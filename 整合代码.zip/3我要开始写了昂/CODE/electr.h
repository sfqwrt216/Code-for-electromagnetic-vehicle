#ifndef __ELECTR_H
#define __ELECTR_H


 



#define ELECTR_CH_A  ADC_P06
#define ELECTR_CH_B  ADC_P11
#define ELECTR_CH_C  ADC_P14
#define ELECTR_CH_D  ADC_P15
#define ELECTR_CH_E  ADC_P16
#define ELECTR_CH_F  ADC_P00
#define ELECTR_CH_G  ADC_P01

                   

  /*ELECTR_CH_D ��ʱ��û��ʹ��*/              
// �±�
#define CH__A 0
#define CH__B 1
#define CH__C 2
#define CH__D 3
#define CH__E 4
#define CH__F 5
#define CH__G 6

#define CH__NUM 7

//// Ҫ��3�ı���
//#define ELECTR_FILTER_DEPTH 10

typedef struct
{
    int primary[CH__NUM];   //ԭʼ����
    int ch_max[CH__NUM];
    int ch_min[CH__NUM];
    int ch_data[CH__NUM];   //��һ��֮��

    int error;

} Eelectr_t;

extern Eelectr_t electr;


void electr_init(void);
void electr_para_init(void);
void electr_read(void);
int electr_get_error(int mode);





#endif
