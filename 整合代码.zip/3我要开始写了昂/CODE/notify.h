#ifndef __NOTIFY_H_
#define __NOTIFY_H_

#define LED P52
#define BUZZER P32



#define LED_ON()        LED = 0
#define LED_OFF()       LED = 1
#define LED_TOG()		LED = !LED



#define BUZZER_ON()     BUZZER = 1
#define BUZZER_OFF()    BUZZER = 0

typedef struct
{
    int time;
} BUZZER_t;



extern BUZZER_t buzzer;    //�ⲿ�ɵ��õĽṹ��


void buzzer_delay(int ms);
void buzzer_server(void);        

#endif