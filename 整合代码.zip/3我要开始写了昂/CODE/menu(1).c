#include "headfile.h"
#include "common.h"
float ppppp;
extern char func_index;//menu��current
int forme=0;
int ppp=0;
int ran,cou[6],coun[17],codee,keyy1,keyy2,keyy3,keyy4,pp;//codeeΪ����ѡ��,��ʼֵΪ0�����Ӳ���,ranΪ����������ʽ
///**��0��**  P5.0  P5.1  P3.7  P1.7���ֱ���128*160�����ַ�һ��16����ʾ10��*/
void fun_b01(void)//����  ����  ȷ��(++)  ����
{
	lcd_clear(RED);//��ʾͼƬ
}
void show1(void)
{
	if(forme!=0)
	{lcd_clear(WHITE);}
	lcd_showstr(8,0,"select");//
	lcd_showstr(8,1,"change");//
	lcd_showstr(8,2,"imu660");//
	lcd_showstr(8,3,"barrier");
	lcd_showstr(8,4,"dianci");//
	lcd_showstr(8,5,"Round");//
	lcd_showstr(8,6,"speed");//
	lcd_showstr(8,7,"Electr_PID");
	forme=0;	
}	
void show2(void)
{
	lcd_showstr(8,0,"code a");	
	lcd_showstr(8,1,"code b");
	lcd_showstr(8,2,"code c");
	lcd_showstr(8,3,"run");
	if(forme!=0)
	{lcd_clear(WHITE);}	
	forme=0;	
}	

void show3(void)
{
	lcd_showstr(8,0,"speed&imu");	
	lcd_showstr(8,1,"Round");//show7
	lcd_showstr(8,2,"Electr_PID");
	lcd_showstr(8,3,"barieer");	
	lcd_showstr(8,4,"Lgogo");
	lcd_showstr(8,5,"Rgogo");
	lcd_showstr(8,6,"Lerror");
	lcd_showstr(8,7,"Rerror");
	lcd_showint16(72,4,motor.left.gogo_givespeed);	
	lcd_showint16(72,5,motor.right.gogo_givespeed);	//motor.left.error
	lcd_showint16(72,6,motor.left.error);	
	lcd_showint16(72,7,motor.right.error);	//motor.left.error	
	if(forme!=0)
	{lcd_clear(WHITE);}
	forme=0;	
}	
void show4(void)//�Ĳ�
{
	lcd_showstr(8,0,"Lgive");	
	lcd_showstr(8,1,"Rgive");
	lcd_showstr(8,2,"RP");
	lcd_showstr(8,3,"RI");		
	lcd_showstr(8,4,"LP");	
	lcd_showstr(8,5,"LI");
	lcd_showstr(8,6,"imuP");	
	lcd_showstr(8,7,"imuD");	
	lcd_showint16(72,0,motor.left.giveset_speed);
	lcd_showint16(72,1,motor.right.giveset_speed);
	lcd_showint16(72,2,PID_para.speedR.kP);
	lcd_showfloat(72,3,PID_para.speedR.kI,2);
	lcd_showint16(72,4,PID_para.speedL.kP);
	lcd_showfloat(72,5,PID_para.speedL.kI,2);
	lcd_showfloat(72,6,PID_para.angular.kP,2);
	lcd_showfloat(72,7,PID_para.angular.kD,2);
	if(forme!=0)	
	{lcd_clear(WHITE);}
	forme=0;
}	
void show5(void)//��ʾ
{
	lcd_showstr(8,0,"P1");	
	lcd_showstr(8,1,"D1");
	lcd_showstr(8,2,"P2");	
	lcd_showstr(8,3,"D2");	
	lcd_showstr(8,5,"P3");	
	lcd_showstr(8,6,"D3");	
	lcd_showstr(8,4,"PWM");
	lcd_showint16(72,0,PID_fenduan.turnto.turnP1);	
	lcd_showint16(72,1,PID_fenduan.turnto.turnD1);
	lcd_showint16(72,2,PID_fenduan.turnto.turnP2);	
	lcd_showint16(72,3,PID_fenduan.turnto.turnD2);	
	lcd_showint16(72,5,PID_fenduan.turnto.turnP3);
	lcd_showint16(72,6,PID_fenduan.turnto.turnD3);	
	lcd_showint16(72,4,motor.left.now_pwm);
	if(forme!=0)
	{lcd_clear(WHITE);}
	forme=0;	
}

void show6(void)
{
	lcd_showstr(8,0,"Dir");	
	lcd_showstr(8,1,"Len1");
	lcd_showstr(8,2,"Len2");
	lcd_showstr(8,3,"Len3");
	lcd_showstr(8,4,"allLen");		//element.round.left_yaw=-20; element.round.right_yaw=20;  
	lcd_showstr(8,5,"symbol");
	lcd_showstr(8,6,"dir2");
	lcd_showstr(8,7,"nextmenu");//show10
	lcd_showint16(72,0,element.round.dir);	
	lcd_showint16(72,1,element.round.length1);	
	lcd_showint16(72,2,element.round.length2);	
	lcd_showint16(72,3,element.round.length3);	
	lcd_showint16(72,4,element.round.alllength);	
	lcd_showint16(72,5,element.round.symbol);
	lcd_showint16(72,6,element.round.dir2);	
	if(forme!=0)
	{lcd_clear(WHITE);}
	forme=0;	
}
void show8(void)
{
	lcd_showstr(8,0,"RampLen");	
	lcd_showstr(8,1,"1");
	lcd_showstr(8,2,"2");
	lcd_showstr(8,3,"ramp");	
	lcd_showstr(8,4,"nextmenu");	//element.barrier.length1
	lcd_showstr(8,5,"state");	

	lcd_showint16(72,0,element.barrier.rampLength);
	lcd_showint16(72,1,element.barrier.decisionRange1);
	lcd_showint16(72,2,element.barrier.decisionRange2);	
	lcd_showint16(72,3,element.barrier.ramp);	
	lcd_showint16(72,5,element.state);

	if(forme!=0)
	{lcd_clear(WHITE);}
	forme=0;	
}
void show9(void)//motor.left.gogo_givespeed
{
	lcd_showstr(8,0,"length1");	
	lcd_showstr(8,1,"length2");
	lcd_showstr(8,2,"length3");
	lcd_showstr(8,3,"YAW1");	
	lcd_showstr(8,4,"YAW2");
	lcd_showstr(8,5,"YAW3");

	lcd_showint16(72,0,element.barrier.length1);
	lcd_showint16(72,1,element.barrier.length2);	
	lcd_showint16(72,2,element.barrier.length3);
	lcd_showint16(72,3,element.barrier.yaw1);
	lcd_showint16(72,4,element.barrier.yaw2);	
	lcd_showint16(72,5,element.barrier.yaw3);

	if(forme!=0)
	{lcd_clear(WHITE);}
	forme=0;	
}
void show10(void)
{
	lcd_showstr(8,0,"YAW1");	
	lcd_showstr(8,1,"LYAW");
	lcd_showstr(8,2,"RYAW");
	//lcd_showstr(8,3,"dir3");
	lcd_showint16(72,0,imu.Yaw1);	
	lcd_showint16(72,1,element.round.left_yaw);	
	lcd_showint16(72,2,element.round.right_yaw);
//	lcd_showint16(72,3,	element.round.dir3);
	if(forme!=0)
	{lcd_clear(WHITE);}
	forme=0;	
}
///*********��1��***********/
void fun_b11(void)   
{	
	show1();
	lcd_showstr(0,0,">");
}
void fun_b12(void)   
{
	show1();	
	lcd_showstr(0,1,">");
}

void fun_b13(void)     
{	
	show1();
	lcd_showstr(0,2,">");
}
void fun_d1(void) 
{
	show1();
	lcd_showstr(0,3,">");
}
void fun_d2(void)
{
		if(forme!=0)
		{lcd_clear(WHITE);}
		lcd_showstr(8,0,"distance");	
		lcd_showstr(8,1,"Flag");	
		lcd_showstr(8,2,"finish");	
		lcd_showstr(8,3,"ranish");
		lcd_showstr(8,4,"raleng");
		lcd_showstr(8,5,"2");
		lcd_showstr(8,6,"1");
		  
		lcd_showint16(72,0,tof.distance);	
		lcd_showint16(72,1,element.barrier_flag);	
		lcd_showint16(72,2,element.barrier.finish);	
		lcd_showint16(72,3,element.barrier.rampFinish);	
		lcd_showint16(72,4,element.barrier.rampLength);	
	lcd_showint16(72,6,element.barrier.decisionRange1);	
		lcd_showint16(72,5,element.barrier.decisionRange2);

		forme=0;
}
void fun_d3(void)
{
	show1();
	lcd_showstr(0,4,">");
}
void fun_d4(void)
{
		if(forme!=0)
		{lcd_clear(WHITE);}
		lcd_showstr(8,0,"A");	
		lcd_showstr(8,1,"B");	
		lcd_showstr(8,2,"C");	
		lcd_showstr(8,3,"D");
		lcd_showstr(8,4,"E");
		lcd_showstr(8,5,"F");
		lcd_showstr(8,6,"G");
		lcd_showstr(8,7,"error");
		
		lcd_showint16(72,0,electr.ch_data[0]);	
		lcd_showint16(72,1,electr.ch_data[1]);	
		lcd_showint16(72,2,electr.ch_data[2]);	
		lcd_showint16(72,3,electr.ch_data[3]);	
		lcd_showint16(72,4,electr.ch_data[4]);	
		lcd_showint16(72,5,electr.ch_data[5]);
		lcd_showint16(72,6,electr.ch_data[6]);
		lcd_showint16(72,7,electr.error);
		forme=0;
}

void fun_d5(void)
{
	show1();
	lcd_showstr(0,5,">");		
}

void fun_d6(void)
{
		if(forme!=0)
		{lcd_clear(WHITE);}
		lcd_showstr(8,0,"FLAG");	
		lcd_showstr(8,1,"Finish");	
		lcd_showstr(8,2,"Dir");	
		lcd_showstr(8,3,"Length1");
		lcd_showstr(8,4,"Length2");	
		lcd_showstr(8,5,"Length3");	
		lcd_showstr(8,6,"all");
		lcd_showstr(8,7,"whole");
		
		lcd_showint16(72,0,element.round_flag);	
		lcd_showint16(72,1,element.round.finish);	
		lcd_showint16(72,2,element.round.dir);	
		lcd_showint16(72,3,element.round.length1);	
		lcd_showint16(72,4,element.round.length2);	
		lcd_showint16(72,5,element.round.length3);	
		lcd_showint16(72,6,element.round.alllength);
		lcd_showint16(72,7,motor.whole.length);		
		forme=0;	
}

void fun_d7(void)
{
	show1();
	lcd_showstr(0,6,">");	
}

void fun_d8(void)
{
	if(forme!=0)
	{lcd_clear(WHITE);}	
	
	lcd_showstr(8,0,"LGIVE");		lcd_showint16(72,0,motor.left.giveset_speed);	
    lcd_showstr(8,1,"LNOW");		lcd_showint16(72,1,motor.left.now_speed);	
	lcd_showstr(8,2,"RGIVE");		lcd_showint16(72,2,motor.right.giveset_speed);	
	lcd_showstr(8,3,"RNOW");		lcd_showint16(72,3,motor.right.now_speed);	
	lcd_showstr(8,4,"RP");			lcd_showint16(72,4,PID_para.speedR.kP);	
	lcd_showstr(8,5,"RI");			lcd_showint16(72,5,PID_para.speedR.kI);	
	lcd_showstr(8,6,"LP");			lcd_showint16(72,6,PID_para.speedL.kP);	
	lcd_showstr(8,7,"LI");			lcd_showint16(72,7,PID_para.speedL.kI);	
	forme=0;	
}
void fun_d9(void)
{
	show1();
	lcd_showstr(0,7,">");		
}
void fun_d10(void)
{
	if(forme!=0)
	{lcd_clear(WHITE);}
	lcd_showstr(8,0,"P1");	
	lcd_showstr(8,1,"D1");	
	lcd_showstr(8,2,"P2");	
	lcd_showstr(8,3,"D2");		
	lcd_showstr(8,4,"P3");	
	lcd_showstr(8,5,"D3");			
	lcd_showint16(72,0,PID_fenduan.turnto.turnP1);	
	lcd_showint16(72,1,PID_fenduan.turnto.turnD1);	
	lcd_showint16(72,2,PID_fenduan.turnto.turnP2);	
	lcd_showint16(72,3,PID_fenduan.turnto.turnD2);	
	lcd_showint16(72,4,PID_fenduan.turnto.turnP3);	
	lcd_showint16(72,5,PID_fenduan.turnto.turnD3);		
	forme=0;
}
/*********��2��***********/
void fun_a21(void)     
{	
	show2();
	lcd_showstr(0,0,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
			codee=1;
			//eeprom_trig();
			flashfz();//�Ѳ���ֵ��������
			flash_write();//��������
	}
}

void fun_a22(void)     
{	
	show2();
	lcd_showstr(0,1,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
			codee=2;
			//eeprom_trig();
			flashfz();//�Ѳ���ֵ��������
			flash_write();//��������
		//lcd_clear(RED);
	}
}

void fun_a23(void)     
{
	show2();
	lcd_showstr(0,2,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
			codee=3;
//			eeprom_trig();
			flashfz();//�Ѳ���ֵ��������
			flash_write();//��������
	}
}

void fun_a24(void)     
{
	show2();
	lcd_showstr(0,3,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
			codee=4;
	}
}

void fun_b21(void)     
{
	show3();
	lcd_showstr(0,0,">");	

}

void fun_b22(void)     
{
	show3();
	lcd_showstr(0,1,">");	

}

void fun_b23(void)     
{
	show3();
	lcd_showstr(0,2,">");	
}

void fun_b24(void)     
{	
	show3();
	lcd_showstr(0,3,">");	
}

void fun_c21(void)     
{	
	if(forme!=0)
	{lcd_clear(WHITE);}
	lcd_showstr(0,0,"Yaw");	
	lcd_showstr(0,1,"nowz");
	lcd_showstr(0,2,"P");	
	lcd_showstr(0,3,"I");
	lcd_showint16(72,0,imu.Yaw);
	lcd_showint16(72,1,imu.nowZ);
	lcd_showfloat(72,2,PID_para.angular.kP,3);
	lcd_showfloat(72,3,PID_para.angular.kD,3);
	forme=0;
}

void fun_c22(void)  //û��   
{
	if(forme!=0)
	{lcd_clear(WHITE);}
	lcd_showstr(0,1,">");	
	lcd_showstr(8,0,"runrun");	
	lcd_showstr(8,1,"delays");	
	forme=0;
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
			ran=2;
	}
}
/*********��3��***********/
void fun_b31(void)     
{
	show4();
	lcd_showstr(0,0,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		motor.left.giveset_speed+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		motor.left.giveset_speed-=5;
	}

}

void fun_b32(void)     
{
	show4();
	lcd_showstr(0,1,">");		
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		motor.right.giveset_speed+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		motor.right.giveset_speed-=5;
	}	

}
void fun_b33(void)     
{
	show4();
	lcd_showstr(0,2,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_para.speedR.kP++;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_para.speedR.kP--;
	}

}

void fun_b34(void)     
{
	show4();
	lcd_showstr(0,3,">");	

	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_para.speedR.kI+=0.5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_para.speedR.kI-=0.5;
	}	

}

void fun_b35(void)     
{
	show4();
	lcd_showstr(0,4,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_para.speedL.kP+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_para.speedL.kP-=1;
	}
	
}

void fun_b36(void)     
{
	show4();
	lcd_showstr(0,5,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_para.speedL.kI+=0.5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_para.speedL.kI-=0.5;
	}
	
}

void fun_b37(void)     
{
	show4();
	lcd_showstr(0,6,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_para.angular.kP+=0.01;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_para.angular.kP-=0.01;
	}	

}
void fun_b377(void)     
{
	show4();
	lcd_showstr(0,7,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_para.angular.kD+=0.1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_para.angular.kD-=0.1;
	}	

}
void fun_b38(void)     
{
	show6();
	lcd_showstr(0,0,">");		
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.dir++;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.dir--;
	}

}

void fun_b39(void)     
{
	show6();
	lcd_showstr(0,1,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.length1+=20;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.length1-=20;
	}

}

void fun_b41(void)     
{
	show6();
	lcd_showstr(0,2,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.length2+=10;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.length2-=10;
	}
	
}

void fun_b42(void)     
{	
	show6();
	lcd_showstr(0,3,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.length3+=10;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.length3-=10;
	}
	
}
void fun_b422(void)     
{	
	show6();
	lcd_showstr(0,4,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.alllength+=500;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.alllength-=500;
	}
	
}
void fun_e1(void)     
{	
	show6();
	lcd_showstr(0,5,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.symbol+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.symbol-=1;
	}
		
}
void fun_e2(void)     
{	
	show6();
	lcd_showstr(0,6,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.dir2+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.dir2-=1;
	}
		
}
void fun_e3(void)     
{	
	show6();
	lcd_showstr(0,7,">");	
}
void fun_f1(void)     
{	
	show10();
	lcd_showstr(0,0,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		imu.Yaw1+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		imu.Yaw1-=1;
	}
	
}
void fun_f2(void)     
{	
	show10();
	lcd_showstr(0,1,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.left_yaw+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.left_yaw-=1;
	}
	
}
void fun_f3(void)     
{	
	show10();
	lcd_showstr(0,2,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.round.right_yaw+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.round.right_yaw-=1;
	}
		
}
//void fun_f9(void)     
//{	
//	show10();
//	lcd_showstr(0,3,">");
//	if(!KEY3_PIN)
//	{
//		while(!KEY3_PIN);//���ּ��
//		element.round.right_yaw+=1;
//	}
//	if(!KEY4_PIN)
//	{
//		while(!KEY4_PIN);//���ּ��
//		element.round.right_yaw-=1;
//	}
//		
//}
void fun_b43(void)     
{
	show5();
	lcd_showstr(0,0,">");	
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_fenduan.turnto.turnP1+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_fenduan.turnto.turnP1-=5;
	}
	
}

void fun_b44(void)     
{	
	show5();
	lcd_showstr(0,1,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_fenduan.turnto.turnD1+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_fenduan.turnto.turnD1-=5;
	}	
			
}

void fun_b45(void)     
{	
	show5();
	lcd_showstr(0,2,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_fenduan.turnto.turnP2+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_fenduan.turnto.turnP2-=5;
	}
	
}

void fun_b455(void)     
{	
	show5();
	lcd_showstr(0,5,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_fenduan.turnto.turnP3+=2;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_fenduan.turnto.turnP3-=2;
	}
		
}

void fun_b466(void)     
{	
	show5();
	lcd_showstr(0,6,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_fenduan.turnto.turnD3+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_fenduan.turnto.turnD3-=5;
	}	
	
}
void fun_b46(void)     
{	
	show5();
	lcd_showstr(0,3,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		PID_fenduan.turnto.turnD2+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		PID_fenduan.turnto.turnD2-=5;
	}	
	
	ppppp=100*PID_para.turn.kB;
	
}

void fun_b47(void)     
{	
	show8();
	lcd_showstr(0,0,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.rampLength+=1000;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.rampLength-=1000;
	}
		
}

void fun_b48(void)     
{
	show8();
	lcd_showstr(0,1,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.decisionRange1+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.decisionRange1-=5;
	}

}
void fun_b487(void)     
{
	show8();
	lcd_showstr(0,2,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.decisionRange2+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.decisionRange2-=5;
	}
	
}
void fun_b4888(void) 
{
	show8();
	lcd_showstr(0,3,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.ramp+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.ramp-=1;
	}
			
}
void fun_b4222(void) 
{
	show8();
	lcd_showstr(0,4,">");//����μ��˵�		
}
void fun_e199(void) 
{
	show9();
	lcd_showstr(0,0,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.length1+=100;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.length1-=100;
	}
		
}
void fun_e200(void) 
{
	show9();
	lcd_showstr(0,1,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.length2+=100;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.length2-=100;
	}
			
}
void fun_e211(void) 
{
	show9();
	lcd_showstr(0,2,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.length3+=100;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.length3-=100;
	}
			
}
void fun_f4(void) 
{
	show9();
	lcd_showstr(0,3,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.yaw1+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.yaw1-=1;
	}
			
}
void fun_f5(void) 
{
	show9();
	lcd_showstr(0,4,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.yaw2+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.yaw2-=1;
	}
			
}
void fun_f6(void) 
{
	show9();
	lcd_showstr(0,5,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		element.barrier.yaw3+=1;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		element.barrier.yaw3-=1;
	}
			
}
void fun_f7(void) 
{
	show3();
	lcd_showstr(0,4,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		motor.left.gogo_givespeed+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		motor.left.gogo_givespeed-=5;
	}
	
			
}
void fun_f8(void) 
{
	show3();
	lcd_showstr(0,5,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		motor.right.gogo_givespeed+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		motor.right.gogo_givespeed-=5;
	}
			
}
void fun_f9(void) 
{
	show3();
	lcd_showstr(0,6,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		motor.left.error+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		motor.left.error-=5;
	}
			
}
void fun_f10(void) 
{
	show3();
	lcd_showstr(0,7,">");
	if(!KEY3_PIN)
	{
		while(!KEY3_PIN);//���ּ��
		motor.right.error+=5;
	}
	if(!KEY4_PIN)
	{
		while(!KEY4_PIN);//���ּ��
		motor.right.error-=5;
	}
			
}
void fun_b48888(void) 
{
	show8();
	lcd_showstr(0,5,">");			
}
key_table table[67]=
{
	//��0��
	{0,0,0,1,0,(*fun_b01)},		//ȷ��
    //��1��
	{1,1,2,4,1,(*fun_b11)},		//����ѡ��
	{2,2,3,8,2,(*fun_b12)},		// ����
	{3,3,31,12,3,(*fun_b13)},	//����
    //��2��
	{4,1,5,4,4,(*fun_a21)},		//����һ				
	{5,1,6,5,5,(*fun_a22)},		//�����
	{6,1,7,6,6,(*fun_a23)},		//������	
	{7,1,4,7,7,(*fun_a24)},		//������
	
	{8,1,9,14,8,(*fun_b21)},	//����					
	{9,1,10,21,9,(*fun_b22)},	//·��andб��
	{10,1,11,25,10,(*fun_b23)},	//˫���ٶ��ڻ�				                	
	{11,1,63,29,11,(*fun_b24)},	//�����⻷
	
	{12,1,12,12,12,(*fun_c21)},	//��������			
	{13,1,12,13,13,(*fun_c22)},	//�ȴ�һ�뷢��		                	
    //��3��		b--,c++,ֻ�е�����
	{14,8,15,14,14,(*fun_b31)},	// motor.left.giveset_speed
	{15,8,16,15,15,(*fun_b32)},	// motor.right.giveset_speed
	{16,8,17,16,16,(*fun_b33)},	//PID_para.speedR.kP
	{17,8,18,17,17,(*fun_b34)},	//PID_para.speedR.kI       
	{18,8,19,18,18,(*fun_b35)},	//PID_para.speedL.kP
	{19,8,20,19,19,(*fun_b36)},	//PID_para.speedL.kI
	{20,8,41,20,20,(*fun_b37)},	// PID_para.angular.kP  	
	
	{21,8,22,21,21,(*fun_b38)},	//PID_para.angular.kD	                	
	{22,8,23,22,22,(*fun_b39)},	//PID_fenduan.turnto.turnP1
	{23,8,24,23,23,(*fun_b41)},	//PID_fenduan.turnto.turnD1              	
	{24,8,45,24,24,(*fun_b42)},	//PID_fenduan.turnto.turnP2
	
	{25,8,26,25,25,(*fun_b43)},	//PID_fenduan.turnto.turnD2
	{26,8,27,26,26,(*fun_b44)},	//element.round.dir 
	{27,8,28,27,27,(*fun_b45)},	//element.round.length1
	{28,8,42,28,28,(*fun_b46)},	//element.round.length2
	
	{29,8,30,29,29,(*fun_b47)},	
	{30,8,44,30,30,(*fun_b48)},	
	
	{31,31,33,32,31,(*fun_d1)},	//�������
	{32,1,32,32,32,(*fun_d2)},	//�������
	{33,33,35,34,33,(*fun_d3)},	//�������
	{34,1,34,34,34,(*fun_d4)},	//�������
	{35,35,37,36,35,(*fun_d5)},	//�������
	{36,1,36,36,36,(*fun_d6)},	//�������
	{37,37,39,38,37,(*fun_d7)},	//�������
	{38,1,38,38,38,(*fun_d8)},	//�������
	{39,39,1,40,39,(*fun_d9)},	//�������
	{40,1,40,40,40,(*fun_d10)},	//�������
	{41,8,14,41,41,(*fun_b377)},//�������
	{42,8,43,42,42,(*fun_b455)},//�������
	{43,8,25,43,43,(*fun_b466)},//�������
	{44,8,46,44,44,(*fun_b487)},	//element.round.alllength
	{45,8,49,45,45,(*fun_b422)},	//element.round.alllength
	{46,8,47,46,46,(*fun_b4888)},	//element.round.alllength
	{47,8,48,54,47,(*fun_b4222)},	//element.round.alllength
	{48,8,63,48,48,(*fun_b48888)},	//element.round.alllength
	{49,8,50,49,49,(*fun_e1)},	//element.round.alllength
	{50,8,51,50,50,(*fun_e2)},	//element.round.alllength	  
	{51,8,21,57,51,(*fun_e3)}	,	//fun_e18
	{52,8,53,52,52,(*fun_e1)}	,	//fun_e18
	{53,8,29,53,53,(*fun_e1)},		//fun_e18
	{54,47,55,54,54,(*fun_e199)},		//fun_e18
	{55,47,56,55,55,(*fun_e200)},		//fun_e18
	{56,47,60,56,56,(*fun_e211)},		//fun_e18
	{57,51,58,57,57,(*fun_f1)},		//fun_e18	
	{58,51,59,58,58,(*fun_f2)},		//fun_e18	
	{59,51,57,59,59,(*fun_f3)},		//fun_e18	
	{60,47,61,60,60,(*fun_f4)},		//fun_e18	
	{61,47,62,61,61,(*fun_f5)},		//fun_e18	
	{62,47,54,62,62,(*fun_f6)},		//fun_e18	
	{63,1,64,63,63,(*fun_f7)},		//fun_e18	
	{64,1,65,64,64,(*fun_f8)},		//fun_e18	
	{65,1,66,65,65,(*fun_f9)},		//fun_e18	
	{66,1,8,66,66,(*fun_f10)}		//fun_e18	
};

void menue()
{
	if(codee!=4)
	{
		//�����ǲ˵��Ĵ���
		keyy1=KEY1_PIN;
		keyy2=KEY2_PIN;
		keyy3=KEY3_PIN;
		keyy4=KEY4_PIN;
		delay_ms(20);		
		(*table[func_index].current_operation)();//ִ�е�ǰ��������
		if(keyy1==0|keyy2==0|keyy3==0|keyy4==0)//ҳ����ת
		{
			if(!keyy1)
			{
				func_index = table[func_index].back;
				while(!KEY1_PIN);//���ּ��
				forme++;
			}
			if(!keyy2)
			{
				func_index = table[func_index].down; 
				while(!KEY2_PIN);//���ּ��
				forme++;
			}
			if(!keyy3)
			{
				func_index = table[func_index].enter;
				while(!KEY3_PIN);//���ּ��
				forme++;
			}
			if(!keyy4)
			{
				func_index = table[func_index].jian;
				while(!KEY4_PIN);//���ּ��
				forme++;
			}
		}
		keyy1=1;//���ð���״̬
		keyy2=1;
		keyy3=1;
		keyy4=1;	
}
	}

//������˼·������Ƿ��а������£����°���������back������Ѵ�ʱcurrent��Ӧ��backֵ��ֵ��current
//current_operation_index = table[func_index].current_operation;
//���ִ��current��Ӧ�ĺ�����ִ�в���Ϊ (*current_operation_index)();//ִ�е�ǰ��������