#ifndef __IMU660_H_
#define __IMU660_H_

#define DT 0.002f       //����ʱ��2ms

typedef struct
{
    float Z;              //�˲����  ���ٶȵ�λ��/s
    float Yaw;            //�����
    float nowZ;
    float lastZ;
    float preZ;
    float errZ;
	
    char state;
	
	  float Y; 
	  float Yaw1;   
	  float nowY;
	  float lastY;
	  float preY;
	  float errY;
} IMU_t;

extern IMU_t imu;

void imu_init(void);
void imu_read(void);

#endif