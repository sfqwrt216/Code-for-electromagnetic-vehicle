#ifndef __FLASHH_H
#define __FLASHH_H

#include "common.h"
#include "headfile.h"
#include "stdlib.h"

//extern float your_var[18],yourr_var[18];
void flashfz(void);
void flashzt(void);
void flash_read(void);
void flash_write(void);
extern int your_var[43],yourr_var[43];//��Ž�flash������
void Bytee(float f,unsigned char byte[]);
void Float_to_Bytee(float f,unsigned char byte[]);
#endif
