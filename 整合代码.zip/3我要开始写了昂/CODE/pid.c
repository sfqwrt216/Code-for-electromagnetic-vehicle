#include "headfile.h"

Para_t PID_para;
Info_t PID_info;
Fenduan_t PID_fenduan;


void pid_para_init(PID_para_t *Para, float p, float i, float d, float t, float b)
{
    Para->kP = p;
    Para->kI = i;
    Para->kD = d;
    Para->kT = t;
    Para->kB = b;
}

void pid_info_init(PID_info_t *Info)
{
    Info->nowError = 0;
    Info->lastError = 0;
    Info->preError = 0;
    Info->lastData = 0;
    Info->errorSum = 0;
}
void fenduanpid_init()
{
	PID_fenduan.turnto.turnP1=0;
	PID_fenduan.turnto.turnI1=0;
	PID_fenduan.turnto.turnD1=0;
	PID_fenduan.turnto.turnP2=0;
	PID_fenduan.turnto.turnI2=0;
	PID_fenduan.turnto.turnD2=0;
	PID_fenduan.turnto.turnP3=0;
	PID_fenduan.turnto.turnI3=0;
	PID_fenduan.turnto.turnD3=0;
	
}





int PID_Position(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint)
{
    int Position;

    Info->nowError = (int)(SetPoint - NowPoint); //���

    Info->errorSum += Info->nowError;
	
    Info->errorSum = limit_ab(Info->errorSum, -90, 90);      //������Ҫ�޷�
	
                                                  //�������ֱ����PID_para.angle��KP
    Position  = Para->kP * Info->nowError
	
            + Para->kI * Info->errorSum     
	
            + Para->kD * (Info->nowError - Info->lastError);//P就是让他驱动控制器靠近目标值   
                                         //D消除曲线抖动相当于一个阻尼器  I消除稳态误差使其消除稳定之后的相对值
    Info->preError = Info->lastError;
    Info->lastError = Info->nowError;
    Info->lastData = NowPoint;
    
	  
       
    return Position;
}




int PID_Increase(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint)
{
    int Increase;

    Info->nowError = (int)(SetPoint - NowPoint);

    Increase    = Para->kP * (Info->nowError - Info->lastError)
                + Para->kI * Info->nowError
                + Para->kD * (Info->nowError - 2 * Info->lastError + Info->preError);

    Info->preError = Info->lastError;
    Info->lastError = Info->nowError;
    Info->lastData = NowPoint;
	
	
/*     increase    Ҳ��Ҫ�޷�
*/ 
    return Increase;
}



 // ��:   PID_DynamicP(&PID_para.turn, &PID_info.turn, electr.error, 0);  
int PID_DynamicP(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint)
{
    int Actual;
    float kp;

    Info->nowError = (int)(SetPoint - NowPoint);

    //kp�����ɶ��κ���
    kp = (Info->nowError * 1.0 * Info->nowError) / 1000 * Para->kT;
    kp = f_abs(kp) + Para->kP;

    Actual  = kp * Info->nowError          
            + Para->kD * ((0.8 * Info->nowError + 0.2 * Info->lastError) - Info->lastError);
    //��������˲�

    Info->lastError = Info->nowError;

    return Actual;
}

