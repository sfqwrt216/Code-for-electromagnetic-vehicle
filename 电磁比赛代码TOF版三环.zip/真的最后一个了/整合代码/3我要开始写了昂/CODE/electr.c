#include "headfile.h"

Eelectr_t electr;
//����Ҫ���ľ���ADC��ʼ��
void electr_init(void)
{
    adc_init(ELECTR_CH_A, ADC_SYSclk_DIV_8);
    adc_init(ELECTR_CH_B, ADC_SYSclk_DIV_8);
    adc_init(ELECTR_CH_C, ADC_SYSclk_DIV_8);
    adc_init(ELECTR_CH_D, ADC_SYSclk_DIV_8);
    adc_init(ELECTR_CH_E, ADC_SYSclk_DIV_8);
	  adc_init(ELECTR_CH_F, ADC_SYSclk_DIV_8);
	  adc_init(ELECTR_CH_G, ADC_SYSclk_DIV_8);
}
//���Ҫ���ľ��ǲ�����ʼ��
void electr_para_init(void)
{
    electr.ch_data[CH__A] = 0;
    electr.ch_data[CH__B] = 0;
    electr.ch_data[CH__C] = 0;
    electr.ch_data[CH__D] = 0;
    electr.ch_data[CH__E] = 0;    
	  electr.ch_data[CH__F] = 0;
    electr.ch_data[CH__G] = 0;

    electr.ch_max[CH__A] = 2300;
    electr.ch_max[CH__B] = 2300;
    electr.ch_max[CH__C] = 2300;
    electr.ch_max[CH__D] = 2300;
    electr.ch_max[CH__E] = 2300;
	  electr.ch_max[CH__F] = 2300;
    electr.ch_max[CH__G] = 2300;


    electr.ch_min[CH__A] = 50;
    electr.ch_min[CH__B] = 20;
    electr.ch_min[CH__C] = 20;
    electr.ch_min[CH__D] = 200;
    electr.ch_min[CH__E] = 20;
		electr.ch_min[CH__F] = 20;
    electr.ch_min[CH__G] = 50;

    electr.primary[CH__A] = 0;
    electr.primary[CH__B] = 0;
    electr.primary[CH__C] = 0;
    electr.primary[CH__D] = 0;
    electr.primary[CH__E] = 0;
		electr.primary[CH__F] = 0;
    electr.primary[CH__G] = 0;

}

/*
//-------------------------------------------------------------------------------------------------------------------
//  @brief     electr_read֮�����Ͻ�һ��  electr_get_error(int mode)
//  @param             
//  @param      
//  @return    
//  Sample usage:             �õ����ǹ�һ��֮��Ĳ��� Ҳ����0~100֮���
//--------------------------------------------------------------------------------------------------
*/


void electr_read(void)
{
    int times = 15, i;
    float electr_sum[7] = { 0, 0, 0, 0,0,0,0};
    float ftemp;

    for (i = 0; i < times; i++)
    {
        electr_sum[0] += adc_once(ELECTR_CH_A, ADC_12BIT);
        electr_sum[1] += adc_once(ELECTR_CH_B, ADC_12BIT);
  			electr_sum[2] += adc_once(ELECTR_CH_C, ADC_12BIT);
        electr_sum[3] += adc_once(ELECTR_CH_D, ADC_12BIT);
        electr_sum[4] += adc_once(ELECTR_CH_E, ADC_12BIT);
  			electr_sum[5] += adc_once(ELECTR_CH_F, ADC_12BIT);
			  electr_sum[6] += adc_once(ELECTR_CH_G, ADC_12BIT);
        
    }
    
		//#define CH__NUM 7
		
    for (i = 0; i < CH__NUM; i++)
    {
        electr.primary[i] = electr_sum[i] / times;
    }



     //��һ��
     for (i = 0; i < CH__NUM; i++)
     {
        ftemp = ((float)electr.primary[i] - (float)electr.ch_min[i]) * 100.0 / (electr.ch_max[i] - electr.ch_min[i]);
        electr.ch_data[i] = (int)ftemp;
				
				 //buzzer_delay(400);
     }

}


// �Ľ�����������!
// mode: 1 ��Ⱥ� 2 ��ȺͲ� 3��Ⱥ͸Ľ� 4 ��ȺͲ�Ľ�     
int electr_get_error(int mode)
{
    float error = 0;
    float sb1=0;
	  float sb2=0;
	  float cha=0;
	  float he=0;
	  float right=0;
	  float left=0;
//Err = (A(L-R) + B(LM-RM)) / (A(L+R) + C�OLM-RM�O)  ׿����ʦ�Ĳ�ȺͲʽ   �������ֱֵ�Ӷ����Ĵ�С�ж�һ�¾�OK��

	
	
//	// ���м�����˵
//if(electr.ch_data[CH__A]+electr.ch_data[CH__B]+electr.ch_data[CH__C]+electr.ch_data[CH__D]+electr.ch_data[CH__E]+
//			electr.ch_data[CH__F]+electr.ch_data[CH__G]<100)
//		{
//			motor.left.giveset_speed=0;
//			motor.right.giveset_speed=0;
//		}


    

//		else 
     if(mode==4)/*��ɿƼ����Ĳ�Ⱥ͹�ʽ*/
		{                    
			sb1= square(electr.ch_data[CH__A])+square(electr.ch_data[CH__B]);
			//���� ��a1ƽ��+a2ƽ��+a3ƽ����
      sb2=square(electr.ch_data[CH__F	])+square(electr.ch_data[CH__G]);
			//���� ��b1ƽ��+b2ƽ��+b3ƽ����
			
			 sb1=sqrt(sb1);
			 sb2=sqrt(sb2);
			
        cha=sb1-sb2; 
	      he=sb1+sb2;
			
			error=(float)(cha*100/he);
		}

    return error;
}

