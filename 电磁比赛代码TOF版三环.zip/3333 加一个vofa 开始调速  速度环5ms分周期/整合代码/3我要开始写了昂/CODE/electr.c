#include "headfile.h"

Eelectr_t electr;
//����Ҫ���ľ���ADC��ʼ��
void electr_init(void)
{
    adc_init(ELECTR_CH_A, ADC_SYSclk_DIV_8);
    adc_init(ELECTR_CH_B, ADC_SYSclk_DIV_8);
    adc_init(ELECTR_CH_C, ADC_SYSclk_DIV_8);
    adc_init(ELECTR_CH_D, ADC_SYSclk_DIV_8);
    adc_init(ELECTR_CH_E, ADC_SYSclk_DIV_8);
}
//���Ҫ���ľ��ǲ�����ʼ��
void electr_para_init(void)
{
    electr.ch_data[CH__A] = 0;
    electr.ch_data[CH__B] = 0;
    electr.ch_data[CH__C] = 0;
    electr.ch_data[CH__D] = 0;
    electr.ch_data[CH__E] = 0;    

    electr.ch_max[CH__A] = 2300;
    electr.ch_max[CH__B] = 2300;
    electr.ch_max[CH__C] = 2300;
    electr.ch_max[CH__D] = 2300;
    electr.ch_max[CH__E] = 2300;

    electr.ch_min[CH__A] = 150;
    electr.ch_min[CH__B] = 20;
    electr.ch_min[CH__C] = 200;
    electr.ch_min[CH__D] = 50;
    electr.ch_min[CH__E] = 150;

    electr.primary[CH__A] = 0;
    electr.primary[CH__B] = 0;
    electr.primary[CH__C] = 0;
    electr.primary[CH__D] = 0;
    electr.primary[CH__E] = 0;

}

/*
//-------------------------------------------------------------------------------------------------------------------
//  @brief     
//  @param             
//  @param      
//  @return    
//  Sample usage:             electr_read֮�����Ͻ�һ��  electr_get_error(int mode)
//--------------------------------------------------------------------------------------------------
*/


void electr_read(void)
{
    int times = 16, i;
    float electr_sum[5] = { 0, 0, 0, 0,0};
    float ftemp;

    for (i = 0; i < times; i++)
    {
        electr_sum[0] += adc_once(ELECTR_CH_A, ADC_12BIT);
        electr_sum[1] += adc_once(ELECTR_CH_B, ADC_12BIT);
        electr_sum[2] += adc_once(ELECTR_CH_D, ADC_12BIT);
        electr_sum[3] += adc_once(ELECTR_CH_E, ADC_12BIT);
			  electr_sum[4] += adc_once(ELECTR_CH_C, ADC_12BIT);
        
    }
    
		//#define CH__NUM 5
		
    for (i = 0; i < CH__NUM; i++)
    {
        electr.primary[i] = electr_sum[i] / times;
    }



     //��һ��
     for (i = 0; i < CH__NUM; i++)
     {
        ftemp = ((float)electr.primary[i] - (float)electr.ch_min[i]) * 100.0 / (electr.ch_max[i] - electr.ch_min[i]);
        electr.ch_data[i] = (int)ftemp;
				
				 //buzzer_delay(400);
     }

}


// �Ľ�����������!
// mode: 1 ��Ⱥ� 2 ��ȺͲ� 3��Ⱥ͸Ľ� 4 ��ȺͲ�Ľ�     
int electr_get_error(int mode)
{
    float error = 0;
    
//Err = (A(L-R) + B(LM-RM)) / (A(L+R) + C�OLM-RM�O)  ׿����ʦ�Ĳ�ȺͲʽ   �������ֱֵ�Ӷ����Ĵ�С�ж�һ�¾�OK��

	
	
	// ���м�����˵
	
    if (electr.ch_data[CH__A]  + electr.ch_data[CH__E] + electr.ch_data[CH__B]+ electr.ch_data[CH__D]< 30)
  {
     return 0;// ����������
   }
		
	
	
	
		
		
		
//��Ⱥ�   ֱ�Ӿ���  A-E/A+E           �൱�ھ��Ƕ� ֱ�����ֱȽϺ�һ��  
    if (mode == 1)
    {
        error = (electr.ch_data[CH__A] - electr.ch_data[CH__E]) * 100.0 / (electr.ch_data[CH__A] + electr.ch_data[CH__E]);
    }
		
		
		
		
		
		//��ȺͲ�       A-E + B-D  / A+E  +  B-D       B��D����ǰ��ֵ��
		                //A-E+B-D    /  A+E+B-D   ���Ϊ��
		else if (mode == 2)
    {
        if (electr.ch_data[CH__B] > electr.ch_data[CH__F])
					
            error = (electr.ch_data[CH__A] - electr.ch_data[CH__G] + electr.ch_data[CH__B] - electr.ch_data[CH__F]) * 100.0 / (electr.ch_data[CH__A] + electr.ch_data[CH__G] + electr.ch_data[CH__B] - electr.ch_data[CH__F]);
       
				else         //A+B-D-E    /    A+E+D-B        ���Ϊ��
            error = (electr.ch_data[CH__A] - electr.ch_data[CH__G] + electr.ch_data[CH__B] - electr.ch_data[CH__F]) * 100.0 / (electr.ch_data[CH__A] + electr.ch_data[CH__G] - electr.ch_data[CH__B] + electr.ch_data[CH__F]);
    }
		
		  else  if (mode == 3)
    {
        error = (electr.ch_data[CH__B] - electr.ch_data[CH__D]) * 100.0 / (electr.ch_data[CH__B] + electr.ch_data[CH__D]);
    }
		
		
		
//	//��Ⱥ͸Ľ�   A-E  /	 A+E+C       �������һ��C��ʵ  ��û�ж��������ô����Ӱ��
//		else if (mode == 3)
//    {
//        error = (electr.ch_data[CH__A] - electr.ch_data[CH__E]) * 100.0 / (electr.ch_data[CH__A] + electr.ch_data[CH__E] + electr.ch_data[CH__C]);
//    }
//		
//		
//		
//		
//	//��ȺͲ�Ľ�   	 A-E + B-D     /    A+E   +  B-D  +  C       B��D����ǰ��ֵ��
//		else if (mode == 4)
//    {
//        if (electr.ch_data[CH__B] > electr.ch_data[CH__D])
//            error = (electr.ch_data[CH__A] - electr.ch_data[CH__E] + electr.ch_data[CH__B] - electr.ch_data[CH__D]) * 100.0 / (electr.ch_data[CH__A] + electr.ch_data[CH__E] + electr.ch_data[CH__B] - electr.ch_data[CH__D] + electr.ch_data[CH__C]);
//        else 
//            error = (electr.ch_data[CH__A] - electr.ch_data[CH__E] + electr.ch_data[CH__B] - electr.ch_data[CH__D]) * 100.0 / (electr.ch_data[CH__A] + electr.ch_data[CH__E] - electr.ch_data[CH__B] + electr.ch_data[CH__D] + electr.ch_data[CH__C]);        
//    }

    return error;
}

