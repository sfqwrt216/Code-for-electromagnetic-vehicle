
//#include "headfile.h"
//#include "stdlib.h"
//float v,ss,a,b,c;//a��readbufת��������
//uint8 byte[4]={0};//ת�����ܱ�VOFA���յĸ�ʽ
//uint8 text[6]={0};
//uint8 read_buf[7]={0};//���յ�������
//uint8 tail[4]={0x00, 0x00, 0x80, 0x7f};	//֡β
//uint32 dat_len = 0;//���ݳ���
//int i,j;

//typedef union
//{
//	float fdata;
//	unsigned long ldata;
//} FloatLongType;
//uint8 byte[4];
//FloatLongType fl;

//	/*
//	��������fת��Ϊ4���ֽ����ݴ����byte[4]��
//	*/
//void Float_to_Byte(float f,unsigned char byte[])
//	{
//		fl.fdata=f;
//		byte[0]=(unsigned char)fl.ldata;
//		byte[1]=(unsigned char)(fl.ldata>>8);
//		byte[2]=(unsigned char)(fl.ldata>>16);
//		byte[3]=(unsigned char)(fl.ldata>>24);
//	}

//	
//char func_index=0;//menu��current
//void main()
//{	
//	void UART4_Isr();
//	
//	clock_init(SYSTEM_CLOCK_56M);	// ��ʼ��ϵͳƵ��,��ɾ���˾���롣
//		board_init();					// ��ʼ���Ĵ���,��ɾ���˾���롣
//	
//		NVIC_SetPriority(UART4_IRQn,0);
//	wireless_uart_init();

//     system_init();
//	
//    while(1)
//    {
//		
//		//�����Ǵ��ڵ��εĴ���

//			dat_len = wireless_uart_read_buff(read_buf,7);
//			if(dat_len!=0)
//			{

//				for(i=1,j=0;i<7;i++,j++)
//				{text[j]=read_buf[i];}
//				a=atof(text);	
//				switch(read_buf[0])
//				{
//          case 'a':{motor.right.giveset_speed=a;break;}	    //	a
//					case 'b':{ motor.left.giveset_speed=a;break;}      //	b
//					case 'c':{PID_fenduan.turnto.turnP1=a;break;}     // c
//		      case 'd':{PID_fenduan.turnto.turnD1=a;break;}    //	d
//					case 'e':{PID_fenduan.turnto.turnP2=a;break;}    //	e
//					case 'f':{PID_fenduan.turnto.turnD2=a;break;}    //f
//					case 'g':{PID_para.speedL.kP=a;break;}             //	g
//					case 'h':{PID_para.speedR.kP=a;break;}      	  //	h
//					case 'i':{PID_para.speedL.kI=a;break;}						//	i
//					case 'j':{PID_para.speedR.kI=a;break;}					//	j
//					case 'k':{PID_para.angular.kP=a;break;}		     //	k
//					case 'l':{PID_para.angular.kD=a;break;}		     //	l

//         					
//					default:break;					
//				}
//     
//				memset(read_buf,0,7);
//			}

//			 lcd_showstr(0,6,"left");
//			 lcd_showint32(5*8,6,motor.left.now_speed,8);//6
//			
//			
//			lcd_showstr(0,5,"F");
//			lcd_showint32(5*2,5,PID_fenduan.turnto.turnP1,8);//5
//			lcd_showint32(5*8,5,PID_fenduan.turnto.turnD1,8);//5
//			lcd_showint32(5*14,5,PID_fenduan.turnto.turnP2,8);//5
//			lcd_showint32(5*21,5,PID_fenduan.turnto.turnD2,8);//5
//			

//					  lcd_showstr(0,4,"T");
//			lcd_showfloat(5*8,4,PID_para.angular.kP,2,2);
//			lcd_showfloat(5*17,4,PID_para.angular.kD,2,2);
//			
//		  lcd_showstr(0,7,"right");
//		  lcd_showint32(5*8,7,motor.right.now_speed,8);//7
//		
//						

//			
//									lcd_showstr(0,0,"tof");
//									 lcd_showint32(5*8,0,tof.distance,8);      // 0
//									 
//											lcd_showstr(0,1,"imuYaw:");
//									lcd_showfloat(6*12,1,imu.Yaw ,3,1);  //1

//											lcd_showstr(0,2,"error:");
//									lcd_showfloat(6*12,2, electr.error ,3,1);  //2
//									 
//									 lcd_showstr(0,3,"imu.nowZ");
//									 lcd_showint32(7*8,3,  imu.nowZ ,8);    //3
//									 
//									



//										
//	

//             
//    }
//}

////����Ҫ���ĵȲ���  
////1.�����������16.4f

