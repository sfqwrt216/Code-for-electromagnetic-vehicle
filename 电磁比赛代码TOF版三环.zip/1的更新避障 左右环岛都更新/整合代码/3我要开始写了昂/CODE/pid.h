#ifndef __PID_H
#define __PID_H
//
typedef struct
{
    float kP;
    float kI;
    float kD;
    float kT;
    float kB;
} PID_para_t;                                 //pid����

typedef struct
{
    // �����ٶȻ�
    PID_para_t speedL;
    PID_para_t speedR;
    // ˫���ٶȻ�
    PID_para_t speedW;                   
    // ���ٶȻ�
    PID_para_t angular;
    // ����
    PID_para_t turn;          
    PID_para_t angle;      
    // ����λ�û�
    PID_para_t lengthL;
    PID_para_t lengthR;

} Para_t;

extern Para_t PID_para;     //PID_para.angular. kP
/////////////////////////////////////////////////////////////////////////////////////

typedef struct
{
    int nowError;           //����
    int lastError;          //�ϴ�
    int preError;           //���ϴ�
    int lastData;                //�ϴ����
    float errorSum;         //������
} PID_info_t;                                   //pid�� ��Ϣ

typedef struct
{
    // �����ٶȻ�
    PID_info_t speedL;
    PID_info_t speedR;
    // ˫���ٶȻ�
    PID_info_t speedW;
    // ���ٶȻ�
    PID_info_t angular;
    // ����
    PID_info_t turn;
    // �ǶȻ�
    PID_info_t angle;        
    // ����λ�û�
    PID_info_t lengthL;
    PID_info_t lengthR;

} Info_t;
extern Info_t PID_info;


void pid_para_init(PID_para_t *Para, float p, float i, float d, float t, float b);
void pid_info_init(PID_info_t *Info);

//λ��pid   
int PID_Position(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint);
//����pid   
int PID_Increase(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint);

int PID_DynamicP(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint);

#endif
