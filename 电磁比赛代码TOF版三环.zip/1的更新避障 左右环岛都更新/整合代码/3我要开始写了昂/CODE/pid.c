#include "headfile.h"

Para_t PID_para;
Info_t PID_info;


//           ���� pid_para_init(&PID_para.speedL, 1.0, 4.4, 0, 0, 0);
void pid_para_init(PID_para_t *Para, float p, float i, float d, float t, float b)
{
    Para->kP = p;
    Para->kI = i;
    Para->kD = d;
    Para->kT = t;
    Para->kB = b;
}
//           ��:   pid_info_init(&PID_info.speedL);
void pid_info_init(PID_info_t *Info)
{
    Info->nowError = 0;
    Info->lastError = 0;
    Info->preError = 0;
    Info->lastData = 0;
    Info->errorSum = 0;
}

// pid_para_init(&PID_para.angle, 0.4, 0, 0.1, 0, 0);�������ô��init��
/*
//ֻ��p��D��  ����PD���򻷿���
*/

//   ��: PID_Position(&PID_para.angle, &PID_info.angle, icm.Yaw, element.stop.angle);


int PID_Position(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint)
{
    int Position;

    Info->nowError = (int)(SetPoint - NowPoint); //���

    Info->errorSum += Info->nowError;
	
    Info->errorSum = limit_ab(Info->errorSum, -90, 90);      //������Ҫ�޷�
	
                                                  //�������ֱ����PID_para.angle��KP
    Position  = Para->kP * Info->nowError
            + Para->kI * Info->errorSum     //���򻷾�û���
            + Para->kD * (Info->nowError - Info->lastError);

    Info->preError = Info->lastError;
    Info->lastError = Info->nowError;
    Info->lastData = NowPoint;
    
	   //limit_ab( Position , -6000, 6000); //��Ҳ��ȷ�����Ҫ��Ҫ�޷�
       
    return Position;
}




//PID_Increase(&PID_para.speedL, &PID_info.speedL, motor.left.now_speed, motor.left.set_speed);

//    pid_para_init(&PID_para.speedL, 1.0, 4.4, 0, 0, 0);
/* 
    �����ֻ��  PI�����ٶȻ�
*/
int PID_Increase(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint)
{
    int Increase;

    Info->nowError = (int)(SetPoint - NowPoint);

    Increase    = Para->kP * (Info->nowError - Info->lastError)
                + Para->kI * Info->nowError
                + Para->kD * (Info->nowError - 2 * Info->lastError + Info->preError);

    Info->preError = Info->lastError;
    Info->lastError = Info->nowError;
    Info->lastData = NowPoint;
	
	
/*     increase    Ҳ��Ҫ�޷�
*/ 
    return Increase;
}



 // ��:   PID_DynamicP(&PID_para.turn, &PID_info.turn, electr.error, 0);  
int PID_DynamicP(PID_para_t *Para, PID_info_t *Info, float NowPoint, float SetPoint)
{
    int Actual;
    float kp;

    Info->nowError = (int)(SetPoint - NowPoint);

    //kp�����ɶ��κ���
    kp = (Info->nowError * 1.0 * Info->nowError) / 1000 * Para->kT;
    kp = f_abs(kp) + Para->kP;

    Actual  = kp * Info->nowError          
            + Para->kD * ((0.8 * Info->nowError + 0.2 * Info->lastError) - Info->lastError);
    //��������˲�

    Info->lastError = Info->nowError;

    return Actual;
}

