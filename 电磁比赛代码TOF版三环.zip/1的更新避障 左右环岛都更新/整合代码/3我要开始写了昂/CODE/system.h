#ifndef __SYSTEM_H
#define __SYSTEM_H





void system_init(void);
void system_isr_serve(void);


void task_2ms(void);
void task_5ms(void);
void task_9ms(void);
void task_10ms(void);
void task_50ms(void);
void task_250ms(void);

#endif
